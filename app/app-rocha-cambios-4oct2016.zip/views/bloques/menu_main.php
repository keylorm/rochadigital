<div class="menu menu-main">
	<ul class="menu-list">
		<li>
			<a href="/">Inicio</a>
			
		</li>
		<li>
			<a href="/fotografias/buscar-actividad-codigo">Buscar Fotografías</a>
			
		</li>
		<li>
			<a href="/contactenos">Contáctenos</a>
		</li>
	</ul>
</div>