<div class="menu menu-admin">
	<ul class="menu-list">
		<li>
			<a href="/admin/contenido">Contenido</a>
			<ul class="submenu-list">
				<li><a href="/admin/contenido/actividad/">Actividades</a></li>
			</ul>
		</li>
		<li>
			<a href="/admin/contenido/">Taxonomías</a>
			<ul class="submenu-list">
				<li><a href="/admin/taxonomia/institucion/">Instituciones</a></li>
				<li><a href="/admin/taxonomia/estado/">Estados de actividades</a></li>
				<li><a href="/admin/taxonomia/estado-solicitud/">Estados de solicitudes</a></li>
				<li><a href="/admin/taxonomia/categoria/">Categorias</a></li>
				<li><a href="/admin/taxonomia/ano/">Años</a></li>
				<li><a href="/admin/taxonomia/tamanos-fotos/">Tamaños de Fotografías</a></li>
			</ul>
		</li>
		<li>
			<a href="/admin/solicitud/listado-solicitudes">Solicitudes</a>
		</li>
	</ul>
</div>