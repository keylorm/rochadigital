<div class="menu menu-admin-user">
	<ul class="menu-list">
		<li>
			<a href="/admin/dashboard/">Dashboard</a>

		</li> | 
		<li>
			<a href="/admin/logout/">Cerrar Sesion</a>
		</li>
	</ul>
</div>