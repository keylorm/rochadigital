<div class="w-container"><h2>Información de Contacto</h2>
				<p>Correo: <a href="mailto:info@rochadigital.co.cr">info@rochadigital.co.cr</a><br />
				Teléfonos: <a href="tel:+50688300706">+506 8830 0706</a><br />
				<a href="tel:+50689516801">+506 8951 6801</a><br />
				</p>
	</div>